from django.contrib import admin
from . models import My_model

# Register your models here.


admin.site.register(My_model)