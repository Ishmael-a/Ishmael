from django.shortcuts import render,redirect
from django.http import HttpResponse
import os
from django.conf import settings
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages

from ugspace.models import My_model
from .forms import UserRegisterForm

# from ugspace.forms import UserRegisterForm
# Create your views here.


def index(request):
     context = {
        'models' : My_model.objects.all().order_by('-date_posted')
     }

     return render(request,'ugspace/index.html', context)


def about(request):
    return render(request,'ugspace/about.html')

def login(request):
    return render(request,'ugspace/login.html')

def register(request):
    if request.method == "POST":
        form=UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Hi {username}, your account was created successfully')
            return redirect('/dashboard')
    else:
        form = UserRegisterForm()

    return render(request,'ugspace/register.html',{'form': form})


def dashboard(request):
    return render(request,'ugspace/dashboard.html')

def my_model(request):
    context = {
        'models' : My_model.objects.all()
    }
    return render(request,'ugspace/index.html' ,context)
    
    
# def download(request, path):
#     file_path = os.path.join(settings.MEDIA_ROOT, path)
#     if os.path.exists(file_path):
#         with open(file_path, 'rb') as fh:
#             response = HttpResponse(fh.read(), content_type = "application/pdf")
#             response = ['Content-Disposition'] = 'inline; filename =' + os.path.basename(file_path)
#             return response
#     raise Http404
    
    
