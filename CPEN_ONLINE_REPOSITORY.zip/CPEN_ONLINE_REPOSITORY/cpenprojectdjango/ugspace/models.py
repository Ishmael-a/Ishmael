from distutils.command.upload import upload
from email.policy import default
from django.db import models

# Create your models here.
class My_model(models.Model):

    title = models.CharField(max_length=100)
    content = models.TextField()
    date_posted = models.DateTimeField(auto_now_add = True)
    author = models.CharField(max_length=50)
    thumb = models.ImageField(default="{%static 'images/mime.png'%}", blank = True, upload_to= "media/images")
    pdf = models.FileField(upload_to="media/static", default='default value')

    def __str__(self):
        return self.title

