package com.example.sign_in_up

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
