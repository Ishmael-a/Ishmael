# Replicate Design in Flutter

Sign-in / Sign-Up page with User-Authentification on Firebase

## Packages used / paquets utilisés 

provider: version 6.0.2
http: version 0.13.4


## ORIGINAL DESIGN

![original.png](/images/original.png) 
![cap1.png](/images/cap1.png)




